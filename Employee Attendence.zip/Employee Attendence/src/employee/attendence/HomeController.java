/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee.attendence;

import employee.attendence.db.DBConn;
import employee.attendence.model.Attendence;
import employee.attendence.model.HomeTable;
import java.net.URL;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import jssc.SerialPort;
import jssc.SerialPortEvent;
import jssc.SerialPortException;
import jssc.SerialPortList;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 * FXML Controller class
 *
 * @author anwar
 */
public class HomeController extends AnchorPane implements Initializable {

    private EmployeeAttendence application;

    @FXML
    private TextArea serialLog;
    @FXML
    private ComboBox<String> cbxPort;
    @FXML
    private Button btnConnect;

    ObservableList<String> portList;

    private SerialPort serialPort;
    private String rfid = "";
    private Sql2o sql2o;
   
    private List<HomeTable> myList;
    
    @FXML
    private Text responseText;

    public void setApp(EmployeeAttendence application) {
        this.application = application;
    }

    private void detectPort() {
        portList = FXCollections.observableArrayList();

        String[] serialPortNames = SerialPortList.getPortNames();
        for (String name : serialPortNames) {
            System.out.println(name);
            portList.add(name);
        }
    }

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        detectPort();
        cbxPort.setItems(portList);
        
        sql2o = new Sql2o(DBConn.DBURL, DBConn.USERNAME, DBConn.PASSWORD);
        
        if (portList.size() == 1) {
            portConnect(portList.get(0));
        }
    }

    @FXML
    private void gotoLogin(ActionEvent event) {
        if (serialPort != null && serialPort.isOpened()) {
            try {
                serialPort.closePort();
            } catch (SerialPortException ex) {
                Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        application.gotoLogin();
    }

    @FXML
    private void gotoAbout(ActionEvent event) {

    }

    private Integer isHave(int e_id, Date e_attend) {
        String sql = "select count(e_attend) from app.attendence where e_attend=:e_attend and e_id=:e_id";

        try (Connection con = sql2o.open()) {
            return con.createQuery(sql)
                    .addParameter("e_attend", e_attend)
                    .addParameter("e_id", e_id)
                    .executeScalar(Integer.class);
        }
    }

    private void takeAttendence(String rfid) {
        Date e_attend = Date.valueOf(LocalDate.now());
        Time e_in = Time.valueOf(LocalTime.now());
        Time e_out = Time.valueOf(LocalTime.now());

        int e_id = getEmployeeID(rfid);
        String e_name = getEmployeeName(rfid);

        Attendence attend = new Attendence(
                e_attend, e_id, e_in, e_out
        );

        HomeTable recent = new HomeTable(e_id, e_name, e_in, "In");

        if (isHave(e_id, e_attend) == 1) {
            String sql = "update app.attendence set "
                    + "e_out = :e_out where e_attend=:e_attend and e_id=:e_id";
            try (Connection conn = sql2o.open()) {
                conn.createQuery(sql).bind(attend).executeUpdate();
                System.out.println("Successfully updated.");
                recent.setType("Out");
                
            }

        } else {
            //insert into database
            String sql = "insert into app.attendence("
                    + "e_attend,"
                    + "e_id,"
                    + "e_in ) values (:e_attend,:e_id,:e_in)";

            try (Connection conn = sql2o.open()) {
                conn.createQuery(sql).bind(attend).executeUpdate();
                System.out.println("Successfully inserted.");
                
            }

        }

    }

    private Integer getEmployeeID(String rfid) {
        String sql = "select e_id from app.employee where e_rfid=:e_rfid";

        try (Connection con = sql2o.open()) {
            return con.createQuery(sql)
                    .addParameter("e_rfid", rfid)
                    .executeScalar(Integer.class);
        }
    }

    private String getEmployeeName(String rfid) {
        String sql = "select e_name from app.employee where e_rfid=:e_rfid";

        try (Connection con = sql2o.open()) {
            return con.createQuery(sql)
                    .addParameter("e_rfid", rfid)
                    .executeScalar(String.class);
        }
    }

    @FXML
    private void connectSerial(ActionEvent event) {
        if (btnConnect.getText().equalsIgnoreCase("connect")) {
            if (cbxPort.getValue() != null
                    && !cbxPort.getValue().isEmpty()) {
                portConnect(cbxPort.getValue());
            }
        } else {
            try {
                serialPort.closePort();
                btnConnect.setText("Connect");
                responseText.setText("Press Connect for Listen");
            } catch (SerialPortException ex) {
                System.err.println("Error in closing serial port:" + ex);
            }
        }
    }

    private void portConnect(String port) {
        try {
            if(serialPort == null){
                serialPort = new SerialPort(port);
            }

            serialPort.openPort();
            DBConn.COMMPORT = cbxPort.getValue();

            btnConnect.setText("Disconnect");
            responseText.setText("Waiting for Response.....");

            serialPort.setParams(SerialPort.BAUDRATE_9600, SerialPort.DATABITS_8,
                    SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);

            serialPort.addEventListener((SerialPortEvent spe) -> {
                if (spe.isRXCHAR() && spe.getEventValue() > 0) {
                    try {
                        String receiveData = serialPort.readString(spe.getEventValue());
                        rfid = rfid + receiveData;

                        if (rfid.startsWith("s") && rfid.endsWith("e")) {
                            rfid = rfid.replace("s", "").replace("e", "");
                            takeAttendence(rfid);
                            rfid = "";
                        }

                        System.out.println(receiveData);
                        Platform.runLater(() -> {
                            serialLog.appendText(receiveData);
                        });
                    } catch (SerialPortException ex) {
                        System.err.println("Error in receiving string from COM-port: " + ex);
                    }
                }
            });

        } catch (SerialPortException ex) {
            System.err.println("Error");
            btnConnect.setText("Connect");
            responseText.setText("Press Connect for Listen");
        }
    }

}
