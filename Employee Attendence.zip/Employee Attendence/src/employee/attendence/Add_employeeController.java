/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee.attendence;

import employee.attendence.db.DBConn;
import employee.attendence.model.Employee;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import jssc.SerialPort;
import jssc.SerialPortEvent;
import jssc.SerialPortException;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 * FXML Controller class
 *
 * @author anwar
 */
public class Add_employeeController implements Initializable {

    @FXML
    private TextField tfName;
    @FXML
    private TextField tfAddress;
    @FXML
    private TextField tfMobile;
    @FXML
    private ImageView ivRenterProfile;
    @FXML
    private Button btnSave;
    @FXML
    private Button btnCancel;
    @FXML
    private TextField tfID;
    @FXML
    private TextField tfDepartment;
    @FXML
    private TextField tfAssign;
    @FXML
    private Button cardAssign;

    private Image image;
    private byte[] imagebyte;

    private EmployeeAttendence application;
    private Sql2o sql2o;

    private boolean isRepeate;
    private Employee employee;
    
    private String receiveData = "";
    
    SerialPort serialPort;

    public void setApp(EmployeeAttendence application) {
        this.application = application;
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        sql2o = new Sql2o(DBConn.DBURL, DBConn.USERNAME, DBConn.PASSWORD);
    }

    //file choser configration
    private void configureFileChooser(final FileChooser fileChooser) {
        fileChooser.setTitle("Select Renter Profile Picture");
        fileChooser.setInitialDirectory(
                new File(System.getProperty("user.home"))
        );
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Images", "*.jpg", "*.png", "*.jpeg"),
                new FileChooser.ExtensionFilter("PNG", "*.png")
        //new FileChooser.ExtensionFilter("All Files", "*.*")
        );
    }

    @FXML
    private void browseImage(MouseEvent event) {
        FileChooser fileChooser = new FileChooser();
        configureFileChooser(fileChooser);
        File file = fileChooser.showOpenDialog(application.stage);
        if (file != null) {
            try {
                imagebyte = Files.readAllBytes(file.toPath());
                image = new Image(file.toURI().toString());
                ivRenterProfile.setImage(image);
            } catch (IOException ex) {
                Logger.getLogger(Add_employeeController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @FXML
    private void addRenter(ActionEvent event) {

        try (Connection conn = sql2o.open()) {
//             e_id, e_rfid , e_name, e_department, e_address, e_phoneno, e_photo

            String sql = "insert into app.employee("
                    + "e_id,"
                    + "e_name,"
                    + "e_department,"
                    + "e_address,"
                    + "e_phoneno,"
                    + "e_rfid"
                    + ") values (:e_id,:e_name,:e_department,:e_address,:e_phoneno,:e_rfid)";

            employee = new Employee(
                    Integer.parseInt(tfID.getText()),
                    tfAssign.getText(),
                    tfName.getText(),
                    tfAddress.getText(),
                    tfMobile.getText(),
                    tfDepartment.getText(),
                    imagebyte
            );

            conn.createQuery(sql).bind(employee).executeUpdate();
            Alert alart = new Alert(Alert.AlertType.INFORMATION, "Successfylly Added.", ButtonType.OK);
            alart.showAndWait();

            //clear all
            tfAddress.setText("");
            tfDepartment.setText("");
            tfName.setText("");
            tfAssign.setText("");
            tfID.setText("");
            tfMobile.setText("");
        }
    }

    @FXML
    private void gotoHome(ActionEvent event) throws SerialPortException {
        isRepeate = true;
        if ( serialPort != null && serialPort.isOpened()) {
            serialPort.closePort();
        }
        application.gotoAdmin();
    }

    @FXML
    private void setRFID(ActionEvent event) {
        tfAssign.setPromptText("Swap the card...");
        receiveData = "";
        try {
            serialPort = new SerialPort(DBConn.COMMPORT);

            serialPort.openPort();
            serialPort.setParams(SerialPort.BAUDRATE_9600, SerialPort.DATABITS_8,
                    SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);

            serialPort.addEventListener((SerialPortEvent spe) -> {
                if (spe.isRXCHAR() && spe.getEventValue() > 0) {
                    try {
                        receiveData = receiveData + serialPort.readString(spe.getEventValue());
                        if(receiveData.startsWith("s")){
                            if(receiveData.endsWith("e")){
                                Platform.runLater(() -> {
                                    tfAssign.setText(receiveData.replace("s", "").replace("e", ""));
                                });
//                                System.out.print(receiveData);
                                serialPort.closePort();
                            }
                            
                        }
                        
                        System.out.print(receiveData);
                        
                    } catch (SerialPortException ex) {
                        System.err.println("Error in receiving string from COM-port: " + ex);
                    }
                }
            });

        } catch (SerialPortException ex) {
            System.err.println("Error");
        }

    }

}
