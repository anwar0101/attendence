/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee.attendence.model;

/**
 *
 * @author anwar
 */
public class Employee {
    private String createTable = 
            "create table app.employee(e_id int NOT NULL, e_rfid varchar(50), e_name varchar(20) NOT NULL, e_department varchar(50), e_address varchar(100), e_phoneno varchar(20), e_photo blob)";
  
            
    /**
     *
     */
    
    private int e_id;
    private String e_rfid;
    private String e_name;
    private String e_address;
    private String e_phoneno;
    private String e_department;
    private byte[] e_photo;

    public Employee(int e_id, String e_rfid, String e_name, String e_address, String e_phoneno, String e_department, byte[] r_photo) {
        this.e_id = e_id;
        this.e_rfid = e_rfid;
        this.e_name = e_name;
        this.e_address = e_address;
        this.e_phoneno = e_phoneno;
        this.e_department = e_department;
        this.e_photo = r_photo;
    }

    public int getE_id() {
        return e_id;
    }

    public void setE_id(int e_id) {
        this.e_id = e_id;
    }

    public String getE_rfid() {
        return e_rfid;
    }

    public void setE_rfid(String e_rfid) {
        this.e_rfid = e_rfid;
    }

    public String getE_name() {
        return e_name;
    }

    public void setE_name(String e_name) {
        this.e_name = e_name;
    }

    public String getE_address() {
        return e_address;
    }

    public void setE_address(String e_address) {
        this.e_address = e_address;
    }

    public String getE_phoneno() {
        return e_phoneno;
    }

    public void setE_phoneno(String e_phoneno) {
        this.e_phoneno = e_phoneno;
    }

    public String getE_department() {
        return e_department;
    }

    public void setE_department(String e_department) {
        this.e_department = e_department;
    }

    public byte[] getE_photo() {
        return e_photo;
    }

    public void setE_photo(byte[] r_photo) {
        this.e_photo = r_photo;
    }
    
    
    
}
