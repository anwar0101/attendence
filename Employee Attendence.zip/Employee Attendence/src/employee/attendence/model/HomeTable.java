/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee.attendence.model;

import java.sql.Time;

/**
 *
 * @author anwar
 */
public class HomeTable {
    private int id;
    private String name;
    private Time accessTime;
    private String type;

    public HomeTable(int id, String name, Time accessTime, String type) {
        this.id = id;
        this.name = name;
        this.accessTime = accessTime;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Time getAccessTime() {
        return accessTime;
    }

    public void setAccessTime(Time accessTime) {
        this.accessTime = accessTime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    
}
