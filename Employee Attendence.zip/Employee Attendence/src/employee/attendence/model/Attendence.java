/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee.attendence.model;

import java.sql.Date;
import java.sql.Time;

/**
 *
 * @author anwar
 */
public class Attendence {
    //"create table app.attendence(e_attend date not null, e_id int NOT NULL, e_in time, e_out time)";
    private Date e_attend;
    private int e_id;
    private Time e_in;
    private Time e_out;

    public Attendence(Date e_attend, int e_id, Time e_in, Time e_out) {
        this.e_attend = e_attend;
        this.e_id = e_id;
        this.e_in = e_in;
        this.e_out = e_out;
    }
    
    

    public Date getE_attend() {
        return e_attend;
    }

    public void setE_attend(Date e_attend) {
        this.e_attend = e_attend;
    }

    public int getE_id() {
        return e_id;
    }

    public void setE_id(int e_id) {
        this.e_id = e_id;
    }

    public Time getE_in() {
        return e_in;
    }

    public void setE_in(Time e_in) {
        this.e_in = e_in;
    }

    public Time getE_out() {
        return e_out;
    }

    public void setE_out(Time e_out) {
        this.e_out = e_out;
    }
    
}
