/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee.attendence;

import employee.attendence.model.User;
import employee.attendence.security.Authonicator;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 *
 * @author anwar
 */
public class EmployeeAttendence extends Application {

    public Stage stage;
    private User loggedUser;
    private final double MINIMUM_WINDOW_WIDTH = 800.0;
    private final double MINIMUM_WINDOW_HEIGHT = 600.0;

    Logger log = Logger.getLogger(EmployeeAttendence.class.getName());

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Application.launch(EmployeeAttendence.class, (java.lang.String[]) null);
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            stage = primaryStage;
            stage.setTitle("Employee Attendence");
            stage.setMinWidth(MINIMUM_WINDOW_WIDTH);
            stage.setMinHeight(MINIMUM_WINDOW_HEIGHT);
            gotoHome();
            primaryStage.show();
        } catch (Exception ex) {
            log.log(Level.INFO, null, ex);
        }
    }

    public User getLoggedUser() {
        return loggedUser;
    }

    public boolean userLogging(String userId, String password) {
        Authonicator autho = new Authonicator(userId, password);
        if (Authonicator.validate(userId, password)) {
            loggedUser = User.getInstance();
            loggedUser.setUsername(userId);
            gotoAdmin();
            return true;
        } else {
            return false;
        }
    }

    public void gotoLogin() {
        try {
            LoginController login = (LoginController) replaceSceneContent("login.fxml");
            login.setApp(this);
        } catch (Exception ex) {
            log.log(Level.SEVERE, null, ex);
        }
    }

    public void gotoHome() {
        try {
            HomeController home = (HomeController) replaceSceneContent("home.fxml");
            home.setApp(this);
        } catch (Exception ex) {
            log.log(Level.SEVERE, null, ex);
        }
    }

    public void gotoAdmin() {
        try {
            AdminController home = (AdminController) replaceSceneContent("admin.fxml");
            home.setApp(this);
        } catch (Exception ex) {
            log.log(Level.SEVERE, null, ex);
        }
    }
    
    public void gotoAddEmployee() {
        try {
            Add_employeeController home = (Add_employeeController) replaceSceneContent("add_employee.fxml");
            home.setApp(this);
        } catch (Exception ex) {
            log.log(Level.SEVERE, null, ex);
        }
    }
    public void gotoViewEmployee() {
        try {
            ViewemployeeController home = (ViewemployeeController) replaceSceneContent("viewemployee.fxml");
            home.setApp(this);
        } catch (Exception ex) {
            log.log(Level.SEVERE, null, ex);
        }
    }
    public void gotoReport() {
        try {
            ReportController home = (ReportController) replaceSceneContent("report.fxml");
            home.setApp(this);
        } catch (Exception ex) {
            log.log(Level.SEVERE, null, ex);
        }
    }
    public void gotoAdminOption() {
        try {
            AdminoptionsController home = (AdminoptionsController) replaceSceneContent("adminoptions.fxml");
            home.setApp(this);
        } catch (Exception ex) {
            log.log(Level.SEVERE, null, ex);
        }
    }

    private Initializable replaceSceneContent(String fxml) throws Exception {
        FXMLLoader loader = new FXMLLoader();
        InputStream in = EmployeeAttendence.class.getResourceAsStream(fxml);
        loader.setBuilderFactory(new JavaFXBuilderFactory());
        loader.setLocation(EmployeeAttendence.class.getResource(fxml));
        AnchorPane page;
        try {
            page = (AnchorPane) loader.load(in);
        } finally {
            in.close();
        }
        Scene scene = new Scene(page, 800, 600);
        stage.setScene(scene);
        stage.sizeToScene();
        return (Initializable) loader.getController();
    }

}
