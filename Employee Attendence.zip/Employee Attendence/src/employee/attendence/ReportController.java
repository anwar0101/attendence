/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee.attendence;

import employee.attendence.db.DBConn;
import employee.attendence.model.Attendence;
import java.net.URL;
import java.sql.Date;
import java.sql.Time;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 * FXML Controller class
 *
 * @author anwar
 */
public class ReportController extends AnchorPane implements Initializable {

    @FXML
    private DatePicker datePicker;
    @FXML
    private TableView<Attendence> tableReport;
    @FXML
    private TableColumn<Attendence, Number> colSl;
    @FXML
    private TableColumn<Attendence, String> colName;
    @FXML
    private TableColumn<Attendence, Date> colDate;
    @FXML
    private TableColumn<Attendence, Time> colAttendTime;
    @FXML
    private TableColumn<Attendence, Time> colLeaveTime;
    @FXML
    private Button btnSaveBill;
    
    private Sql2o sql2o;
    private List<Attendence> myList;
    
    private EmployeeAttendence application;
    
    
    public void setApp(EmployeeAttendence application) {
        this.application = application;
    }
    
    
    private void prepareList() {
        myList = getAllHistory();
    }
    
    private String getEmployeeName(int e_id) {
        String sql = "select e_name from app.employee where e_id=:e_id";

        try (Connection con = sql2o.open()) {
            return con.createQuery(sql)
                    .addParameter("e_id", e_id)
                    .executeScalar(String.class);
        }
    }
    
    private List<Attendence> getAllHistory() {
        String sql
                = "SELECT * from APP.attendence";

        try (Connection con = sql2o.open()) {
            return con.createQuery(sql).executeAndFetch(Attendence.class);
        }
    }
    private List<Attendence> getDayHistory(Date date) {
        String sql
                = "SELECT * from APP.attendence where e_attend = :date";

        try (Connection con = sql2o.open()) {
            return con.createQuery(sql)
                    .addParameter("date", date)
                    .executeAndFetch(Attendence.class);
        }
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        sql2o = new Sql2o(DBConn.DBURL, DBConn.USERNAME, DBConn.PASSWORD);
        
        //sl
        colSl.setCellValueFactory((TableColumn.CellDataFeatures<Attendence, Number> column)
                -> {
            return new ReadOnlyObjectWrapper<>(tableReport.getItems().indexOf(column.getValue()) + 1);
        });
        
        colName.setCellValueFactory((TableColumn.CellDataFeatures<Attendence, String> column)
                -> {
            return new ReadOnlyObjectWrapper<>(getEmployeeName(
                    tableReport.getItems().get(
                            tableReport.getItems().indexOf(column.getValue())).getE_id()));
        });
//        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("e_attend"));
        colAttendTime.setCellValueFactory(new PropertyValueFactory<>("e_in"));
        colLeaveTime.setCellValueFactory(new PropertyValueFactory<>("e_out"));
        
        prepareList();
        ObservableList<Attendence> reports = FXCollections.observableList(myList);
        //set to table view
        tableReport.setItems(reports);
        
    }    

    @FXML
    private void viewReport(ActionEvent event) {
        if (datePicker.getValue() != null) {
            Date date = Date.valueOf(datePicker.getValue());

            myList = getDayHistory(date);
            ObservableList<Attendence> history = FXCollections.observableList(myList);
            tableReport.setItems(history);
        }
    }

    @FXML
    private void printTable(ActionEvent event) {
    }

    @FXML
    private void gotoHome(ActionEvent event) {
        application.gotoAdmin();
    }
    
}
