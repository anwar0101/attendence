/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee.attendence;

import employee.attendence.db.DBConn;
import employee.attendence.model.Employee;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javax.imageio.ImageIO;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 * FXML Controller class
 *
 * @author anwar
 */
public class ViewemployeeController implements Initializable {

    @FXML
    private ListView<EmpolyeeName> lvRenter;
    @FXML
    private TextField tfSearch;
    @FXML
    private GridPane gridPnaeDetails;
    @FXML
    private ImageView ivRenterPic;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnCancel;
    private Sql2o sql2o;
    
    private List<EmpolyeeName> myList;
    private ObservableList<EmpolyeeName> empolyeeNames;
    
    private Text[] text = new Text[5];
    private TextField[] tfFields = new TextField[5];
    
    private boolean isUpdate = false;
    private int selectedID = 0;
    private int dataId = 0;
    
    private EmployeeAttendence application;
    
    public void setApp(EmployeeAttendence application) {
        this.application = application;
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        sql2o = new Sql2o(DBConn.DBURL, DBConn.USERNAME, DBConn.PASSWORD);
        //
        prepareEmployees();
        empolyeeNames = FXCollections.observableList(myList);
        lvRenter.setItems(empolyeeNames);
        btnUpdate.setVisible(false);
        
        lvRenter.setCellFactory((ListView<EmpolyeeName> param) -> new CustomCell());

        lvRenter.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends EmpolyeeName> observable, EmpolyeeName oldValue, EmpolyeeName newValue) -> {
            if (newValue != null) {
                try {
                    getAllRenterDetails(newValue.getE_id(), false);
                    dataId = newValue.getE_id();
                } catch (IOException ex) {
                    Logger.getLogger(EmployeeAttendence.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        //search employee by name
        tfSearch.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            handleSearchByKey2(oldValue, newValue);
        });
        
        int index = 0;
        for (Text te : text) {
            te = new Text();
            te.setFont(new Font(20));
            //gridPnaeDetails.add(te, 1, index);
            text[index++] = te;
        }
        
        index = 0;
        for (TextField te : tfFields) {
            te = new TextField();
            //gridPnaeDetails.add(te, 1, index);
            tfFields[index++] = te;
        }
    }    

    @FXML
    private void renterUpdate(ActionEvent event) {
        String name= tfFields[0].getText();
        String department= tfFields[1].getText();
        String address= tfFields[2].getText();
        String phone= tfFields[3].getText();
        String rfid= tfFields[4].getText();
        
        if(name.length() != 0 && selectedID != 0){
            
            Employee employee = new Employee(
                    selectedID,
                    rfid,
                    name,
                    address,
                    phone,
                    department,
                    null
            );
            
            String sql = "update app.employee set "
                    + "e_name = :e_name,"
                    + "e_address = :e_address,"
                    + "e_phoneno = :e_phoneno,"
                    + "e_department = :e_department where e_id = :e_id";
            try(Connection conn = sql2o.open()){
                conn.createQuery(sql).bind(employee).executeUpdate();
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Successfully Updated.", ButtonType.OK);
                alert.showAndWait();
//                isUpdate = false;
//                selectedID = 0;
            }
        }
    }

    @FXML
    private void gotoHome(ActionEvent event) {
        application.gotoAdmin();
    }
    
    //preparing list 
    private void prepareEmployees() {
        myList = getAllEmpolyeeNames();
    }
    
    //getting employee name and id for listview
    private List<EmpolyeeName> getAllEmpolyeeNames() {
        String sql
                = "SELECT e_id, e_name from APP.Employee";

        try (Connection con = sql2o.open()) {
            return con.createQuery(sql).executeAndFetch(EmpolyeeName.class);
        }
    }
    
    private void deleteRenter(int e_id){
        String sql = "delete from app.employee where e_id=:e_id"; 
        try (Connection conn = sql2o.open()) {
            conn.createQuery(sql)
                    .addParameter("e_id", e_id)
                    .executeUpdate();
            System.out.println("Successfully Deleted");
        }
    }
    
    private void refreshList(){
        prepareEmployees();
        empolyeeNames = FXCollections.observableList(myList);
        lvRenter.setItems(empolyeeNames);
        lvRenter.refresh();
    }
    
    
    private void getAllRenterDetails(int id, boolean isEdit) throws IOException {
        String sql
                = "SELECT * from APP.Employee where e_id = :e_id";

        List<Employee> employees;

        try (Connection con = sql2o.open()) {
            employees = con.createQuery(sql)
                    .addParameter("e_id", id)
                    .executeAndFetch(Employee.class);
        }

        for (Employee e : employees) {

            String[] str = {
                e.getE_name(),
                e.getE_department(),
                e.getE_address(),
                e.getE_phoneno(),
                e.getE_rfid() + ""
            };
            
            if(e.getE_photo()!= null){
                // convert byte array back to BufferedImage
                InputStream in = new ByteArrayInputStream(e.getE_photo());
                BufferedImage buffer = ImageIO.read(in);
                Image image = SwingFXUtils.toFXImage(buffer, null);
                ivRenterPic.setImage(image);
            } else {
                Image im = new Image(EmployeeAttendence.class.getResourceAsStream("usericon.png"));
                ivRenterPic.setImage(im);
            }

            if(isEdit){
                //edit request
                int index = 0;
                for (Text te : text) {
                    gridPnaeDetails.getChildren().remove(te);
                }
                
                index = 0;
                for (TextField te : tfFields) {
                    gridPnaeDetails.getChildren().remove(te);
                    gridPnaeDetails.add(te, 1, index);
                    te.setText(str[index++]);
                }
                btnUpdate.setVisible(true);
                
            } else {
                //view request
                int index = 0;
                for (TextField te : tfFields) {
                    gridPnaeDetails.getChildren().remove(te);
                }
                
                index = 0;
                for (Text te : text) {
                    gridPnaeDetails.getChildren().remove(te);
                    gridPnaeDetails.add(te, 1, index);
                    te.setText(str[index++]);
                }
                btnUpdate.setVisible(false);
                selectedID = 0;
                isUpdate = false;
            }
            
            //set image if not null
            if(e.getE_photo()!= null){
//                BufferedImage img = ImageIO.
//                ivRenterPic.setImage(value);
            }
        }

    }
    
    
    private class EmpolyeeName {

        private int e_id;
        private String e_name;

        public EmpolyeeName(int e_id, String e_name) {
            this.e_id = e_id;
            this.e_name = e_name;
        }

        public int getE_id() {
            return e_id;
        }

        public void setE_id(int e_id) {
            this.e_id = e_id;
        }

        public String getE_name() {
            return e_name;
        }

        public void setE_name(String e_name) {
            this.e_name = e_name;
        }

        
    }
    
    class CustomCell extends ListCell<EmpolyeeName> {

        @Override
        protected void updateItem(EmpolyeeName item, boolean empty) {
            super.updateItem(item, empty); //To change body of generated methods, choose Tools | Templates.
            if (item != null) {
                setText(item.getE_name());
                ContextMenu contextMenu = new ContextMenu();
                
                MenuItem item1 = new MenuItem("Edit");
                item1.setOnAction((ActionEvent e) -> {
                    try {
                        //edit renter info
                        getAllRenterDetails(item.getE_id(), true);
                        //prepareBills(item.getR_Id());
                    } catch (IOException ex) {
                        Logger.getLogger(ViewemployeeController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    isUpdate = true;
                    selectedID = item.getE_id();
                    btnUpdate.setVisible(true);
                });
                
                MenuItem item3 = new MenuItem("Delete");
                item3.setOnAction((ActionEvent e) -> {
                    //delete entry
                    TextInputDialog dialog = new TextInputDialog("BlackHole Tech");
                    dialog.setTitle("Renter Delete Confirmation");
                    dialog.setHeaderText("This is only for developers. You cannot delete Renter becasue error will be occured.");
                    dialog.setContentText("Enter Master Key:");

// Traditional way to get the response value.
                    Optional<String> result = dialog.showAndWait();
                    if (result.isPresent()) {
                        if(result.get().equals("34722645")){
                            deleteRenter(item.getE_id());
                            refreshList();
                        }
                    }
                });
                
                //menu item for view total accounts
                contextMenu.getItems().addAll(item1, item3);
                contextMenu.setStyle("-fx-background-color: #03a9f4; -fx-text-fill: black");
                setContextMenu(contextMenu);
            }
        }

    }
    
    public void handleSearchByKey2(String oldVal, String newVal) {
        // If the number of characters in the text box is less than last time
        // it must be because the user pressed delete
        if ( oldVal != null && (newVal.length() < oldVal.length()) ) {
            // Restore the lists original set of entries 
            // and start from the beginning
            lvRenter.setItems(empolyeeNames);
        }
         
        // Break out all of the parts of the search text 
        // by splitting on white space
        String[] parts = newVal.toUpperCase().split(" ");
 
        // Filter out the entries that don't contain the entered text
        ObservableList<EmpolyeeName> subentries = FXCollections.observableArrayList();
        for (EmpolyeeName entry: lvRenter.getItems() ) {
            boolean match = true;
            String entryText = entry.getE_name();
            for ( String part: parts ) {
                // The entry needs to contain all portions of the
                // search string *but* in any order
                if ( ! entryText.toUpperCase().contains(part) ) {
                    match = false;
                    break;
                }
            }
 
            if ( match ) {
                subentries.add(entry);
            }
        }
        lvRenter.setItems(subentries);
    }
    
}
